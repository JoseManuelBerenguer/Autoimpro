const maxApi = require("max-api");

var publicIp = require('public-ip')

publicIp.v4().then(ip => {
  	console.log("tu direccion pública es", ip);
	maxApi.outlet(ip);
});