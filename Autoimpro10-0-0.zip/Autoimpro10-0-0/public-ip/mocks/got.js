'use strict';
const stub = require('./stub');

module.exports = stub(require('got'), 'get', 0);
